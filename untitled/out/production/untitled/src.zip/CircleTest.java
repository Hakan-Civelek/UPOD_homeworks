import java.util.Scanner;

public class CircleTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Circle circle = new Circle();
        System.out.print("Radius of the circle: ");
        circle.radius = scanner.nextDouble();
        circle.area = circle.calculateArea(circle.radius);
        circle.circumference = circle.calculateCircumference(circle.radius);

        double radiusFromArea = circle.calculateRadiusFromArea(circle.area);
        double radiusFromCircumference = circle.calculateRadiusFromCircumference(circle.circumference);

        System.out.println("area: " + circle.area);
        System.out.println("circumference: " + circle.circumference);
        System.out.println("calculateRadiusFromArea's result: " + radiusFromArea);
        System.out.println("calculateRadiusFromCircumference's result: " + radiusFromCircumference);
    }
}
